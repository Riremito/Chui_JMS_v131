function start() {
    cm.sendOk("Sorry, but the Duey service is unavailable at this time.");//openDuey();
    cm.safeDispose();
}

function action(mode, type, selection) {
}