/* Honorable Rock */

function start() {
    cm.displayGuildRanks();
    cm.dispose();
}