function start() {
    cm.warp(742000104);	
    cm.dispose();
}