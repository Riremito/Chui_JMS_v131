/*
	Magatia - Carson
*/

function start() {
    cm.sendNext("Alchemy... and the alchemist...they both are important. But the most important of all is this town, Magatia, where all that will be fully embraced. The pride and fame of Magatia must be continued. Do you have the power to do that?");
}

function action() {
    cm.dispose();
}