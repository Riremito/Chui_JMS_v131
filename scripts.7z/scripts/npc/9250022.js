function action(mode, type, selection) {
    cm.sendOk("The Fortune System is currently unavailable.");
    cm.dispose();
}