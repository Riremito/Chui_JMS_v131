/*
	Gingerman - Witch Tower
*/

function start() {
    cm.sendSimple("Whoa, I'm all the way up to the top floor! \n\r #L0##bI want to get out of here#k#l");
}

function action(mode, type, selection) {
    cm.warp(980040000, 0);
    cm.dispose();
}