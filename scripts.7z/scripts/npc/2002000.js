function start() {
    if (cm.getMapId() != 209000000) {
        cm.saveLocation("CHRISTMAS");
        cm.warp(209000000);	
        cm.dispose();
    } else {
        var returnMap = cm.getSavedLocation("CHRISTMAS");
	cm.clearSavedLocation("CHRISTMAS");
        cm.warp(returnMap);	
        cm.dispose();
    }
}