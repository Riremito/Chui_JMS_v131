/* Author: aaroncsn (MapleSea Like)
    NPC Name:         Chun Ji
    Map(s):         Victoria Road: Kerning City Construction Site(103010000)
    Description:         Unknown
*/
function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {

    if (mode == -1) {
        cm.dispose();
    } else {
        if (status >= 0 && mode == 0) {
            cm.dispose();
            return;
        }
        if (mode == 1)
            status++;
        else
            status--;
        if(status == 0){
            if(cm.haveItem(4031019)){
                cm.sendNext("Not bad for a nobody like you to have something so precious and rare. What? You want me to decipher the scroll for you? No. Not even the greatest exorcists can handle the scroll that is laden with the forces of evil from ancient times easily.");
            }
            else{
                cm.sendOk("A nobody...leave me alone...");
                cm.dispose();
                }
        }
        else if(status == 1){
            cm.sendNextPrev("But hey... will you hand that scroll over to me? If I decipher this safely, it may help me tremendously in terms of getting rid of the hidden powers of evil all over the world.");
            }
        else if(status == 2){
            cm.sendNextPrev("To decipher it safely, I may need #b50 pieces of Charm of the Undead#k. Get me the charms and the scroll, then I'll give you a daddy of all items I've gathered up from defeating the forces of evil over the years.");
            }
        else if(status == 3){
            if(cm.haveItem(4000008, 50)){
                cm.sendNextPrev("Alright, I'll give you that precious item like I promised. This is called the #rMagic Box#k, and I got this from defeating one of the evil monsters of ancient times. NOT an easy item to acquire.");
                }
            else
                cm.dispose();
            }
        else if(status == 4){
            cm.sendNextPrev("Inside the box contains a hard-to-find item. Unfortunately I lost the key, so I can't open it for you. You can probably open it at #bKerning City#k where there's an unbelievable #rlocksmith#k that may open it for you.");
            }
        else if(status == 5){
            cm.gainItem(4031019, -1);
            cm.gainItem(4000008, -50);
            cm.gainItem(4031017);
            cm.dispose();
            }
    }
}