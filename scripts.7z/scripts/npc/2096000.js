function start() {
	cm.getMap().killMonster(5090001);
	cm.dispose();
}

function action(mode, type, selection) {
}	