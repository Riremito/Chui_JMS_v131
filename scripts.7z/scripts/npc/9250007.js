

function action(mode, type, selection) {
	cm.openShopNPC(48);
    cm.dispose();
}