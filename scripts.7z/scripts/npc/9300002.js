function start() {
    cm.saveLocation("DONGDONGCHIANG");
    cm.warp(700000000);	
    cm.dispose();
}