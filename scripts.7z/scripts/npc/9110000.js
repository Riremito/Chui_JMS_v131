function start() {
    cm.warp(800000000);	
    cm.dispose();
}