var status = -1;

function action(mode, type, selection) {
	cm.warp(211070000, 0);
	cm.dispose();
}