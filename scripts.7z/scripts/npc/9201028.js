function start() {
    cm.dispose();
}