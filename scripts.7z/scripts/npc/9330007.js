function start() {
    cm.warp(740000100);	
    cm.dispose();
}