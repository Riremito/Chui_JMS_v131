var status = -1;

function action(mode, type, selection) {
	cm.sendOk("If you want to be a Cannon Shooter, please talk to Kyrin.");
	cm.dispose();
}