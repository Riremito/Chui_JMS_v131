function start() {
    cm.warp(701000000);	
    cm.dispose();
}