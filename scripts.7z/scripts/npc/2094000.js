var status = -1;
var minLevel = 55;
var maxLevel = 100;

var minPartySize = 3;
var maxPartySize = 6;

function action(mode, type, selection) {
    if (mode == 1) {
	status++;
    } else {
	if (status == 0) {
	    cm.dispose();
	    return;
	}
	status--;
    }
	if (cm.getMapId() == 920010000) { //inside orbis pq
		cm.sendOk("We have to save Chamberlain Eak! Restore the 20 Cloud Pieces!");
		cm.dispose();
		return;
	}
    if (status == 0) {
	if (cm.getParty() == null) { // No Party
	    cm.sendOk("How about you and your party members collectively beating a quest? Here you'll find obstacles and problems where you won't be able to beat it unless with great teamwork. If you want to try it, please tell the #bleader of your party#k to talk to me.\r\n\r\n#rRequirements: " + minPartySize + " Party Members, all between level " + minLevel + " and level " + maxLevel + ".");
	} else if (!cm.isLeader()) { // Not Party Leader
	    cm.sendOk("If you want to try the quest, please tell the #bleader of your party#k to talk to me.");
	} else {
	    // Check if all party members are within PQ levels
	    var party = cm.getParty().getMembers();
	    var mapId = cm.getMapId();
	    var channel = cm.getChannel();
	    var next = true;
	    var levelValid = 0;
	    var inMap = 0;
	    var it = party.iterator();

	    while (it.hasNext()) {
		var cPlayer = it.next();
		if ((cPlayer.getLevel() >= minLevel) && (cPlayer.getLevel() <= maxLevel)) {
		    levelValid += 1;
		} else {
		    next = false;
		}
		if (cPlayer.getMapid() == mapId && cPlayer.getChannel() == channel) {
		    inMap += (cPlayer.getJobId() == 900 ? 6 : 1);
		}
	    }
	    if (party.size() > maxPartySize || inMap < minPartySize) {
		next = false;
	    }
	    if (next) {
		var em = cm.getEventManager("Pirate");
		if (em == null) {
		    cm.sendOk("The PQ has encountered an error. Please report this on the forums, with a screenshot");
		    cm.safeDispose();
		} else {
		    var prop = em.getProperty("state");
		    if (prop.equals("0") || prop == null) {
			em.startInstance(cm.getParty(), cm.getMap());
			cm.dispose();
			return;
		    } else {
			cm.sendOk("�w�g����L����b�̭��D�ԤF �еy��A�i�J�ݬ�");
			cm.safeDispose();
		    }
		}
	    } else {
		cm.sendOk("Your party is invalid. Please adhere to the following requirements:\r\n\r\n#rRequirements: " + minPartySize + " Party Members, all between level " + minLevel + " and level " + maxLevel + ".");
		cm.safeDispose();
	    }
	}
    }
}