/* 	
Ralph (Old Guy in Boat Quay) 
*/

function start() {
    cm.sendOk("I miss the old days man.");
}

function action() {
    cm.dispose();
}	