/* 
 *  Rooney - Happy Ville NPC
 */

var status = -1;
var firstsel = 0;

function action(mode, type, selection) {
	cm.sendOk("Happy Holidays~");
	cm.safeDispose();
}