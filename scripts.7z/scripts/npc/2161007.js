var status = -1;

function action(mode, type, selection) {
	cm.warp(211060200, 0);
	cm.dispose();
}