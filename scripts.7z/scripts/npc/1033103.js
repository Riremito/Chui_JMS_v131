function action(mode, type, selection) {
    cm.dispose();
}