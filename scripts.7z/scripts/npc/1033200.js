var status = -1;

function action(mode, type, selection) {
	cm.dispose();
	cm.openNpc(1033201);
}