/* Door of Dimension
	Enter 3rd job event
*/

function start() {
    if (cm.getQuestStatus(100101) == 1 && !cm.haveItem(4031059)) {
/*    if (cm.getParty() == null) { // No Party
	cm.sendNext("�вն��A�ӧ��");
    } else if (!cm.isLeader()) { // Not Party Leader
	cm.sendNext("�Хs�A�������ӧ��");
    } else if (cm.getParty().getMembers() > 1) {
	cm.sendNext("�ж}�@�ӥu���ۤv������b��ڭ�");
    } else {*/
	var em1 = cm.getEventManager("3rdjob1");
	var em2 = cm.getEventManager("3rdjob2");
	var em3 = cm.getEventManager("3rdjob3");
	var em4 = cm.getEventManager("3rdjob4");
	if (cm.getJob() == 110 || cm.getJob() == 120 || cm.getJob() == 130 && cm.getMapId() == 105070001) {
	    em1.startInstance(cm.getPlayer());
//	    em1.startInstance(cm.getParty(),cm.getMap());
	} else if (cm.getJob() == 210 || cm.getJob() == 220 || cm.getJob() == 230 && cm.getMapId() == 100040106) {
	    em2.startInstance(cm.getPlayer());
//	    em2.startInstance(cm.getParty(),cm.getMap());
	} else if (cm.getJob() == 310 || cm.getJob() == 320 && cm.getMapId() == 105040305) {
	    em3.startInstance(cm.getPlayer());
//	    em3.startInstance(cm.getParty(),cm.getMap());
	} else if (cm.getJob() == 410 || cm.getJob() == 420 && cm.getMapId() == 107000402) {
	    em4.startInstance(cm.getPlayer());
//	    em4.startInstance(cm.getParty(), cm.getMap());
	}
//    }
    } else {
	cm.sendNext("�S�Ƥ��n�ê���");
    }
    cm.dispose();
}

function action(mode, type, selection) {

}