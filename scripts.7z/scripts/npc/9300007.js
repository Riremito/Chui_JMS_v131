function start() {
    var returnMap = cm.getSavedLocation("DONGDONGCHIANG");
    cm.warp(returnMap);	
    cm.dispose();
}