/*
	Kubo the Storageman - Omega Sector : Silo (221000200)
*/

function action(mode, type, selection) {
    cm.sendStorage();
    cm.dispose();
}