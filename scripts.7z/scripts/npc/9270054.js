/*
 * Storage - Encik Musa
 */

function start() {
	cm.sendStorage();
	cm.dispose();
}