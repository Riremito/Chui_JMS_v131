function start() {
	cm.warp(610030020,0);
	cm.removeAll(4001256);
	cm.removeAll(4001257);
	cm.removeAll(4001258);
	cm.removeAll(4001259);
	cm.removeAll(4001260);
	cm.dispose();
}

function action(mode, type, selection) {
}